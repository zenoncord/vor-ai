"use client"

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Cpu } from "lucide-react"

const MODELS = [
  { id: "llama-3.3-70b-versatile", name: "Llama 3.3 70B", badge: "Best" },
  { id: "llama-3.1-8b-instant", name: "Llama 3.1 8B", badge: "Fast" },
  { id: "llama3-70b-8192", name: "Llama 3 70B", badge: null },
  { id: "llama3-8b-8192", name: "Llama 3 8B", badge: null },
  { id: "mixtral-8x7b-32768", name: "Mixtral 8x7B", badge: null },
  { id: "gemma2-9b-it", name: "Gemma 2 9B", badge: null },
]

interface ModelSelectorProps {
  value: string
  onChange: (value: string) => void
}

export function ModelSelector({ value, onChange }: ModelSelectorProps) {
  const selectedModel = MODELS.find(m => m.id === value)
  
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className="w-[180px] bg-card/60 border-border/40 rounded-lg h-10">
        <div className="flex items-center gap-2">
          <Cpu className="w-4 h-4 text-primary" />
          <SelectValue placeholder="Select model">
            {selectedModel?.name}
          </SelectValue>
        </div>
      </SelectTrigger>
      <SelectContent className="bg-card border-border/40">
        {MODELS.map((model) => (
          <SelectItem key={model.id} value={model.id} className="cursor-pointer">
            <div className="flex items-center justify-between gap-3">
              <span>{model.name}</span>
              {model.badge && (
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-primary/10 text-primary font-medium">
                  {model.badge}
                </span>
              )}
            </div>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  )
}
