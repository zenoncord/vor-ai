"use client"

import { Bot, User, Copy, Check } from "lucide-react"
import { cn } from "@/lib/utils"
import { useState } from "react"

interface Message {
  id: string
  role: "user" | "assistant"
  parts: Array<{ type: "text"; text: string }>
}

interface ChatMessageProps {
  message: Message
}

function getMessageText(message: Message): string {
  if (!message.parts || !Array.isArray(message.parts)) return ""
  return message.parts
    .filter((p): p is { type: "text"; text: string } => p.type === "text")
    .map((p) => p.text)
    .join("")
}

export function ChatMessage({ message }: ChatMessageProps) {
  const isUser = message.role === "user"
  const text = getMessageText(message)
  const [copied, setCopied] = useState(false)

  const handleCopy = async () => {
    await navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div
      className={cn(
        "group flex gap-4 p-5 rounded-2xl transition-all",
        isUser 
          ? "bg-primary/5 border border-primary/10" 
          : "bg-card/60 border border-border/40"
      )}
    >
      <div
        className={cn(
          "flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center",
          isUser 
            ? "bg-primary text-primary-foreground" 
            : "bg-primary/10"
        )}
      >
        {isUser ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5 text-primary" />}
      </div>
      <div className="flex-1 space-y-2 overflow-hidden min-w-0">
        <div className="flex items-center justify-between">
          <p className="text-sm font-semibold">{isUser ? "You" : "Vor AI"}</p>
          {!isUser && (
            <button
              type="button"
              onClick={handleCopy}
              className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-lg hover:bg-muted"
              title="Copy response"
            >
              {copied ? (
                <Check className="w-4 h-4 text-primary" />
              ) : (
                <Copy className="w-4 h-4 text-muted-foreground" />
              )}
            </button>
          )}
        </div>
        <div className="prose prose-sm dark:prose-invert max-w-none">
          <p className="whitespace-pre-wrap break-words text-foreground/90 leading-relaxed">{text}</p>
        </div>
      </div>
    </div>
  )
}
