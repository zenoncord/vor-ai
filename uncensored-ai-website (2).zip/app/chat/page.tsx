"use client"

import { useState, useRef, useEffect, useCallback } from "react"
import { ChatMessage } from "@/components/chat/chat-message"
import { ChatInput } from "@/components/chat/chat-input"
import { ModelSelector } from "@/components/chat/model-selector"
import { Button } from "@/components/ui/button"
import { Bot, LogOut, Trash2 } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"

interface Message {
  id: string
  role: "user" | "assistant"
  parts: Array<{ type: "text"; text: string }>
}

export default function ChatPage() {
  const [model, setModel] = useState("llama-3.3-70b-versatile")
  const [messages, setMessages] = useState<Message[]>([])
  const [isChatLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const router = useRouter()
  const supabase = createClient()

  const sendMessage = useCallback(async (text: string) => {
    const userMessage: Message = {
      id: `user-${Date.now()}`,
      role: "user",
      parts: [{ type: "text", text }],
    }

    setMessages((prev) => [...prev, userMessage])
    setIsLoading(true)

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, userMessage],
          model,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to send message")
      }

      const reader = response.body?.getReader()
      if (!reader) throw new Error("No reader")

      const decoder = new TextDecoder()
      let buffer = ""
      let assistantContent = ""
      const assistantId = `assistant-${Date.now()}`

      // Add empty assistant message
      setMessages((prev) => [
        ...prev,
        { id: assistantId, role: "assistant", parts: [{ type: "text", text: "" }] },
      ])

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split("\n")
        buffer = lines.pop() || ""

        for (const line of lines) {
          const trimmed = line.trim()
          if (trimmed.startsWith("data:")) {
            const data = trimmed.slice(5).trim()
            if (data === "[DONE]") continue
            try {
              const parsed = JSON.parse(data)
              if (parsed.type === "text-delta" && parsed.textDelta) {
                assistantContent += parsed.textDelta
                setMessages((prev) =>
                  prev.map((msg) =>
                    msg.id === assistantId
                      ? { ...msg, parts: [{ type: "text", text: assistantContent }] }
                      : msg
                  )
                )
              }
            } catch {
              // Skip invalid JSON
            }
          }
        }
      }
    } catch (error) {
      console.error("Chat error:", error)
    } finally {
      setIsLoading(false)
    }
  }, [messages, model])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSend = (text: string) => {
    sendMessage(text)
  }

  const handleClearChat = () => {
    setMessages([])
  }

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push("/auth/login")
    router.refresh()
  }

  return (
    <div className="flex flex-col h-screen bg-background relative">
      {/* Background decoration */}
      <div className="absolute inset-0 grid-pattern opacity-20 pointer-events-none" />
      
      {/* Header */}
      <header className="relative flex items-center justify-between px-6 py-4 border-b border-border/40 bg-background/80 backdrop-blur-xl z-10">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center animate-pulse-glow">
            <Bot className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="font-semibold text-lg tracking-tight">Vor AI</h1>
            <p className="text-xs text-muted-foreground">Your AI Assistant</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <ModelSelector value={model} onChange={setModel} />
          <Button variant="ghost" size="icon" onClick={handleClearChat} title="Clear chat" className="hover:bg-destructive/10 hover:text-destructive">
            <Trash2 className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={handleLogout} title="Sign out" className="hover:bg-muted">
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </header>

      {/* Messages */}
      <main className="flex-1 overflow-y-auto p-6 relative z-0">
        <div className="max-w-4xl mx-auto space-y-4">
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-[calc(100vh-200px)] text-center">
              <div className="w-24 h-24 rounded-2xl bg-primary/10 flex items-center justify-center mb-8 animate-float">
                <Bot className="w-12 h-12 text-primary" />
              </div>
              <h2 className="text-3xl font-bold mb-3 gradient-text">Welcome to Vor AI</h2>
              <p className="text-muted-foreground max-w-md text-lg leading-relaxed">
                Start a conversation by typing a message below. I can help you with questions, writing, coding, and more.
              </p>
              <div className="flex flex-wrap justify-center gap-2 mt-8">
                {["Write code", "Explain concepts", "Creative writing", "Answer questions"].map((suggestion) => (
                  <button
                    key={suggestion}
                    type="button"
                    onClick={() => handleSend(suggestion)}
                    className="px-4 py-2 rounded-full border border-border/60 bg-card/50 text-sm text-muted-foreground hover:border-primary/40 hover:text-foreground transition-all"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((message) => (
              <ChatMessage key={message.id} message={message} />
            ))
          )}
          {isChatLoading && messages[messages.length - 1]?.role === "user" && (
            <div className="flex gap-4 p-5 rounded-2xl bg-card/60 border border-border/40">
              <div className="flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center bg-primary/10">
                <Bot className="w-5 h-5 text-primary" />
              </div>
              <div className="flex items-center gap-3">
                <div className="flex gap-1.5">
                  <span className="w-2.5 h-2.5 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                  <span className="w-2.5 h-2.5 bg-primary rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                  <span className="w-2.5 h-2.5 bg-primary rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                </div>
                <span className="text-sm text-muted-foreground">Vor is thinking...</span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Input */}
      <footer className="relative p-6 border-t border-border/40 bg-background/80 backdrop-blur-xl z-10">
        <div className="max-w-4xl mx-auto">
          <ChatInput onSend={handleSend} disabled={isChatLoading} />
          <p className="text-center text-xs text-muted-foreground mt-3">
            Vor AI can make mistakes. Consider checking important information.
          </p>
        </div>
      </footer>
    </div>
  )
}
