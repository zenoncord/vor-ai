// API keys for rotation when rate limited
const API_KEYS = [
  process.env.GROQ_API_KEY,
  process.env.GROQ_API_KEY_2,
  process.env.GROQ_API_KEY_3,
].filter(Boolean) as string[]

let currentKeyIndex = 0

async function makeGroqRequest(
  model: string,
  formattedMessages: Array<{ role: string; content: string }>,
  keyIndex: number = 0,
  retryCount: number = 0
): Promise<Response> {
  const apiKey = API_KEYS[keyIndex % API_KEYS.length]
  
  const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages: [
        {
          role: "system",
          content: `You are Vor AI, a helpful, friendly, and knowledgeable AI assistant. You provide clear, accurate, and thoughtful responses to help users with their questions and tasks. Be conversational and engaging while maintaining accuracy.

When writing code, always format it in markdown code blocks with the appropriate language specified (e.g., \`\`\`javascript, \`\`\`python, etc.).`,
        },
        ...formattedMessages,
      ],
      stream: true,
    }),
  })

  // If rate limited (429) or server error, try next API key
  if ((response.status === 429 || response.status >= 500) && retryCount < API_KEYS.length - 1) {
    const nextKeyIndex = (keyIndex + 1) % API_KEYS.length
    currentKeyIndex = nextKeyIndex // Update global index for next request
    return makeGroqRequest(model, formattedMessages, nextKeyIndex, retryCount + 1)
  }

  return response
}

export async function POST(req: Request) {
  const { messages, model = "llama-3.3-70b-versatile" } = await req.json()

  // Convert UI messages to OpenAI format
  const formattedMessages = messages.map((msg: { role: string; parts?: Array<{ type: string; text?: string }> }) => {
    const content = msg.parts
      ?.filter((p: { type: string }) => p.type === "text")
      .map((p: { text?: string }) => p.text || "")
      .join("") || ""
    return { role: msg.role, content }
  })

  const response = await makeGroqRequest(model, formattedMessages, currentKeyIndex)

  if (!response.ok) {
    const error = await response.text()
    return new Response(JSON.stringify({ error }), { status: response.status })
  }

  // Create a transform stream to convert Groq SSE to UI message format
  const encoder = new TextEncoder()
  const decoder = new TextDecoder()

  const stream = new ReadableStream({
    async start(controller) {
      const reader = response.body?.getReader()
      if (!reader) {
        controller.close()
        return
      }

      let buffer = ""
      
      // Send initial message start
      controller.enqueue(encoder.encode(`data: {"type":"start","messageId":"${Date.now()}"}\n\n`))

      try {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break

          buffer += decoder.decode(value, { stream: true })
          const lines = buffer.split("\n")
          buffer = lines.pop() || ""

          for (const line of lines) {
            const trimmed = line.trim()
            if (trimmed.startsWith("data:")) {
              const data = trimmed.slice(5).trim()
              if (data === "[DONE]") {
                controller.enqueue(encoder.encode(`data: {"type":"finish"}\n\n`))
                continue
              }
              try {
                const parsed = JSON.parse(data)
                const content = parsed.choices?.[0]?.delta?.content
                if (content) {
                  controller.enqueue(encoder.encode(`data: {"type":"text-delta","textDelta":"${content.replace(/"/g, '\\"').replace(/\n/g, '\\n')}"}\n\n`))
                }
              } catch {
                // Skip invalid JSON
              }
            }
          }
        }
      } finally {
        reader.releaseLock()
        controller.close()
      }
    },
  })

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  })
}
